#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

from emailSendLib import es


# 发送文本格式
# 发送文本 send_type 参数需要指定为 plain，因为 plain 为默认参数所以可以忽略

# es.send('测试邮件(标题)', '测试邮件(内容)')


# 发送 html 格式
# 发送 html send_type 参数需要指定为 html

html = '''
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8">
    <title>测试邮件</title>
    </head>
    <body>
    
    <h2>测试邮件[内容]</h2>
    <p>HTML 格式测试</p>
    
    </body>
    </html>
'''

# es.send('测试邮件(标题)', html, send_type='html')


# 发送带有 [附件] 的格式：
# 发送文本 send_type 参数需要指定为 annex
# file_path 参数为文件路径

es.send('测试邮件(标题)', '测试邮件(内容)', send_type='annex', file_path='demo.zip')


# 发送带有 [图片] 的格式：
# 发送文本 send_type 参数需要指定为 image
# image_path 参数为图片路径

# es.send('测试邮件(标题)', '测试邮件(内容)', send_type='image', image_path='demo.jpg')
